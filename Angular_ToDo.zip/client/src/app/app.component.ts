import { Component } from '@angular/core';
import axios from 'axios';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular ToDo';
  list: any = [];
  constructor() {
    this.getTasks();
  }
  getTasks() {
    axios({ method: "get", url: `http://localhost:5000/api/tasks` }).then((response) => { this.list = response.data }).catch((error) => { throw error });
  }
  postTask(task: object) {
    axios({ method: "post", url: `http://localhost:5000/api/tasks`, data: task}).then((response) => { console.log(response.data) }).catch((error) => { throw error });
    this.getTasks();
    // pro pripad neuspesneho get pozadavku
    this.getTasks();
  }
  deleteTask(taskID:any) {
    axios({ method: "delete", url: `http://localhost:5000/api/tasks/` + taskID })//axios({ method: "delete", url: `http://localhost:5000/api/tasks/`+task }).then((response) => { console.log(response.data) }).catch((error) => { throw error });
    this.getTasks();
    // pro pripad neuspesneho get pozadavku
    this.getTasks();
  }
}
