const mongoose = require("mongoose");
const express = require("express");
const app = express();
const API_PORT = 5000;
app.use(express.json());
app.listen(API_PORT, () =>
	console.log("Listening on port " + API_PORT + "..."),
);
app.use(function (req, res, next) {
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
	res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
	res.setHeader('Access-Control-Allow-Credentials', true);
	next();
});

mongoose
	.connect("mongodb://localhost:27017", { useNewUrlParser: true })
	.then(() => console.log("Connected to MongoDB!"))
	.catch((error) => console.error("Could not connect to MongoDB... ", error));

const taskSchema = new mongoose.Schema({
	name: String,
	description: String,
	date: String
})

const Task = mongoose.model("Task", taskSchema);

app.get("/api/tasks", async (req, res) => {
	let count = await Task.find();
	res.send(count);
});

app.post("/api/tasks", async (req, res) => {
	let parametres = req.body;
	parametres.date = new Date().toLocaleString('cs-CZ');
	Task.create(parametres)
		.then((result) => {
			res.json(result);
		})
		.catch((err) => {
			res.send("Nepodarilo se ulozit ukol!");
		});
});

app.delete('/api/tasks/:id', (req, res) => {
	Task.findByIdAndDelete(req.params.id)
		.then((result) => {
			if (result) res.json(result);
			else res.status(404).send("Ukol s dan�m id nebyl nalezen!");
		})
		.catch((err) => {
			res.send("Chyba p�i maz�n� ukolu!");
		});
});